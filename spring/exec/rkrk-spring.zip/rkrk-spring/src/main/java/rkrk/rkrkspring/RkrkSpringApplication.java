package rkrk.rkrkspring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RkrkSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(RkrkSpringApplication.class, args);
	}

}
