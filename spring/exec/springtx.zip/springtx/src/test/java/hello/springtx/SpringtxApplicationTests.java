package hello.springtx;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringtxApplicationTests {

	@Test
	void contextLoads() {
	}

}
